/**
 * Flow Static Type Declarations
 */

declare var HALFPI: number;
declare var PI2: number;
declare var PI180: number;

declare var Utilities: any;
declare var Ease: any;
declare var Waves: any;
